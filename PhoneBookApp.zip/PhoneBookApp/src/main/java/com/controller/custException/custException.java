package com.controller.custException;

public class custException extends Exception {

    public custException(String msg) {
        super(msg);
    }
}
