package com.phonebookapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhoneBookAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
